package com.example.config_client_dev;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigClientDevApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConfigClientDevApplication.class, args);
    }
}