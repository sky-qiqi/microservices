package com.example.config_client_pro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigClientProApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConfigClientProApplication.class, args);
    }

}